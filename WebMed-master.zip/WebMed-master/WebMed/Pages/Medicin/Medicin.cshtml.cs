using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections.Generic;

namespace WebMed.Pages.Medicin
{
	public class MedicinModel : PageModel
	{
		[BindProperty(SupportsGet = true)]
		public string? VisibleInfo { get; set; }

		public List<MedicinItem> MedicinList { get; set; } = new List<MedicinItem>
		{
			new MedicinItem { Id = "medicin1", Name = "Paracetamol", Description = "Helps relieve pain and reduce fever." },
			new MedicinItem { Id = "medicin2", Name = "Ibuprofen", Description = "An anti-inflammatory medicine for pain relief." },
			new MedicinItem { Id = "medicin3", Name = "Penicillin", Description = "An antibiotic for bacterial infections." }
		};

		public void OnPost(string medicinId)
		{
			VisibleInfo = medicinId; // Store the selected medicine's ID to show information
		}

		public class MedicinItem
		{
			public string Id { get; set; }
			public string Name { get; set; }
			public string Description { get; set; }
		}
	}
}