using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebMed.Data;
using WebMed.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace WebMed.Pages.Reminders
{
	public class RemindersModel : PageModel
	{
		private readonly ApplicationDbContext _context;

		public RemindersModel(ApplicationDbContext context)
		{
			_context = context;
		}

		[BindProperty]
		public string SelectedMedicineId { get; set; }
		[BindProperty]
		public DateTime ReminderTime { get; set; }
		[BindProperty]
		public string RepeatInterval { get; set; }
		[BindProperty]
		public bool ReminderSet { get; set; }

		public List<Medicine> Medicines { get; set; }

		[BindProperty]
		public int? CustomDaysInterval { get; set; }

		public void OnGet()
		{
			// Ensure RepeatInterval has a default value (e.g., "None") if it's not set
			if (string.IsNullOrEmpty(RepeatInterval))
			{
				RepeatInterval = "None";
			}

			Medicines = _context.Medicines.ToList();

			// If no medicines are in the database, add some default ones
			if (!Medicines.Any())
			{
				_context.Medicines.AddRange(
					new Medicine { Id = "med1", Name = "Paracetamol" },
					new Medicine { Id = "med2", Name = "Ibuprofen" },
					new Medicine { Id = "med3", Name = "Penicillin" }
				);
				_context.SaveChanges();

				// Refresh the list after adding new data
				Medicines = _context.Medicines.ToList();
			}
		}

		public IActionResult OnPost()
		{
			if (Request.Form["setReminder"] == "true")
			{
				// Find the selected medicine
				var medicine = _context.Medicines.FirstOrDefault(m => m.Id == SelectedMedicineId);

				if (medicine != null)
				{
					// If RepeatInterval is null or empty, set it to "None"
					if (string.IsNullOrEmpty(RepeatInterval))
					{
						RepeatInterval = "None";
					}

					// Create a new reminder and save it to the database
					var reminder = new Reminder
					{
						MedicinId = medicine.Id,
						MedicinName = medicine.Name,
						ReminderTime = ReminderTime,
						RepeatInterval = RepeatInterval, // Ensure this is set
						CustomDaysInterval = RepeatInterval == "Custom" ? CustomDaysInterval : (int?)null // Set the custom interval if selected
					};

					_context.Reminders.Add(reminder);
					_context.SaveChanges();

					// Indicate that the reminder was successfully set
					ReminderSet = true;
				}
			}

			// Reload the medicines list after setting the reminder
			Medicines = _context.Medicines.ToList();

			// Return the page with the updated state
			return Page();
		}
	}
}