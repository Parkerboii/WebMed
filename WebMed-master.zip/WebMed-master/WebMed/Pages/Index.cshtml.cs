using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using System.Linq;
using System.Threading.Tasks;
using WebMed.Data;
using WebMed.Models;

public class IndexModel : PageModel
{
    private readonly WebMedContext _context;
    private readonly ILogger<IndexModel> _logger;

    public IndexModel(WebMedContext context, ILogger<IndexModel> logger)
    {
        _context = context;
        _logger = logger;
    }

    [BindProperty]
    public string Username { get; set; }

    [BindProperty]
    public string Password { get; set; }

    public bool LoginFailed { get; set; }
    public bool RegistrationSuccess { get; set; }

    public void OnGet() { }

    public async Task<IActionResult> OnPostLoginAsync()
    {
        var user = _context.Users.FirstOrDefault(u => u.Username == Username && u.Password == Password);

        if (user != null)
        {
            _logger.LogInformation("Login successful for user: {Username}", Username);
            return RedirectToPage("/Homepage"); 
        }
        else
        {
            _logger.LogWarning("Login failed for user: {Username}", Username);
            LoginFailed = true;
            return Page();
        }
    }
}
