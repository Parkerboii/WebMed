﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using WebMed.Data;
using WebMed.Models;

namespace WebMed.Pages.Symptomers
{
    public class CreateModel : PageModel
    {
        private readonly WebMed.Data.WebMedContext _context;

        public CreateModel(WebMed.Data.WebMedContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]
        public Symptomer Symptomer { get; set; } = default!;

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Symptomer.Add(Symptomer);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
