﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WebMed.Data;
using WebMed.Models;
using System.Threading.Tasks;

namespace WebMed.Pages.Symptomers
{
    public class DeleteModel : PageModel
    {
        private readonly WebMedContext _context;

        public DeleteModel(WebMedContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Symptomer Symptomer { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            // Fetch the Symptomer object from the database
            Symptomer = await _context.Symptomer.FirstOrDefaultAsync(m => m.Id == id);

            if (Symptomer == null)
            {
                return NotFound();
            }

            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (Symptomer == null)
            {
                return NotFound();
            }

            // Find the Symptom by ID and remove it
            _context.Symptomer.Remove(Symptomer);
            await _context.SaveChangesAsync();

            // Redirect to the Index page after deletion
            return RedirectToPage("./Index");
        }
    }
}
