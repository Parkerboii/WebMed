﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WebMed.Models;
using WebMed.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace WebMed.Pages.Symptomers
{
    public class IndexModel : PageModel
    {
        private readonly WebMedContext _context;

        public IndexModel(WebMedContext context)
        {
            _context = context;
        }

        public List<Symptomer> Symptomer { get; set; }
        public string ShowPopup { get; set; }

        public async Task OnGetAsync()
        {
  
            Symptomer = await _context.Symptomer.ToListAsync();

        
            if (HttpContext.Session.GetString("PopupTriggered") != "true")
            {
            
                ShowPopup = CheckConsecutiveValues(Symptomer);

             
                if (!string.IsNullOrEmpty(ShowPopup))
                {
                    HttpContext.Session.SetString("PopupTriggered", "true"); 
                }
            }
            else
            {
                ShowPopup = string.Empty; 
            }
        }

        private string CheckConsecutiveValues(List<Symptomer> Symptomer)
        {
            int consecutiveCount = 0;
            List<string> problematicParameters = new List<string>(); 

            foreach (var item in Symptomer)
            {
                if (item.Systoliske_blodtryk < 50 || item.Systoliske_blodtryk > 90)
                {
                    consecutiveCount++;
                    if (!problematicParameters.Contains("Systoliske blodtryk"))
                        problematicParameters.Add("Systoliske blodtryk");
                }
                if (item.Diastoliske_blodtryk < 100 || item.Diastoliske_blodtryk > 160)
                {
                    consecutiveCount++;
                    if (!problematicParameters.Contains("Diastoliske blodtryk"))
                        problematicParameters.Add("Diastoliske blodtryk");
                }
                if (item.Puls < 40 || item.Puls > 80)
                {
                    consecutiveCount++;
                    if (!problematicParameters.Contains("Puls"))
                        problematicParameters.Add("Puls");
                }

                if (consecutiveCount >= 3) 
                {
                    break; 
                }
                else if (item.Systoliske_blodtryk >= 50 && item.Systoliske_blodtryk <= 90 &&
                         item.Puls >= 40 && item.Puls <= 80 &&
                         item.Diastoliske_blodtryk >= 100 && item.Diastoliske_blodtryk <= 160)
                {
                    consecutiveCount = 0; 
                }
            }

            if (problematicParameters.Any())
            {
                return string.Join(", ", problematicParameters);
            }

            return string.Empty; 
        }
    }
}
