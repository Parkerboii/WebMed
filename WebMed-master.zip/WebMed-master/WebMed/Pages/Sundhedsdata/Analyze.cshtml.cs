using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WebMed.Models;
using System.Linq;
using System.Threading.Tasks;
using WebMed.Data;

namespace WebMed.Pages.Symptomers
{
    public class AnalyzeModel : PageModel
    {
        private readonly WebMedContext _context; 

        public AnalyzeModel(WebMedContext context) 
        {
            _context = context;
        }

        public int AverageSystoliske_blodtryk { get; set; }
        public int AverageDiastoliske_blodtryk { get; set; }
        public int AveragePuls { get; set; }
        public int SymptomerCount { get; set; } 
        public List<Symptomer> Symptomers { get; set; }

        public async Task OnGetAsync()
        {
           
            Symptomers = await _context.Symptomer.ToListAsync();

       
            SymptomerCount = Symptomers.Count;

            
            AverageSystoliske_blodtryk = SymptomerCount > 0
                ? (int)Symptomers.Average(m => m.Systoliske_blodtryk)
                : 0;

            AverageDiastoliske_blodtryk = SymptomerCount > 0
                ? (int)Symptomers.Average(m => m.Diastoliske_blodtryk)
                : 0;

            AveragePuls = SymptomerCount > 0
                ? (int)Symptomers.Average(m => m.Puls)
                : 0;
        }

    }
}
