using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using System.Linq;
using System.Threading.Tasks;
using WebMed.Data;
using WebMed.Models;

public class RegisterModel : PageModel
{
    private readonly WebMedContext _context;
    private readonly ILogger<RegisterModel> _logger;

    public RegisterModel(WebMedContext context, ILogger<RegisterModel> logger)
    {
        _context = context;
        _logger = logger;
    }

    [BindProperty]
    public string Username { get; set; }

    [BindProperty]
    public string Password { get; set; }

    [BindProperty]
    public string Role { get; set; }

    public bool RegistrationSuccess { get; set; }
    public bool RegistrationFailed { get; set; }

    public void OnGet() { }

    // POST handler for registration
    public async Task<IActionResult> OnPostRegisterAsync()
    {
        if (_context.Users.Any(u => u.Username == Username))
        {
            _logger.LogWarning("Username already taken: {Username}", Username);
            RegistrationFailed = true; // Registration failed
            return Page();
        }

        var newUser = new User { Username = Username, Password = Password };
        _context.Users.Add(newUser);
        await _context.SaveChangesAsync();

        _logger.LogInformation("New user registered: {Username}", Username);
        RegistrationSuccess = true;
        // Redirect to login page after successful registration
        return RedirectToPage("/Index");
    }
}