using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebMed.Pages
{
    public class HomepageModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
