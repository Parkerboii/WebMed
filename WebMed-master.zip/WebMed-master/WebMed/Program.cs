using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using WebMed.Data;
using Microsoft.Extensions.DependencyInjection;
using WebMed.Models;

namespace WebMed
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

         
            var connectionString = builder.Configuration.GetConnectionString("DefaultConnection") ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");
            builder.Services.AddDbContext<ApplicationDbContext>(options =>
                options.UseSqlServer(connectionString));
            builder.Services.AddDatabaseDeveloperPageExceptionFilter();

            builder.Services.AddDefaultIdentity<IdentityUser>(options => options.SignIn.RequireConfirmedAccount = true)
                .AddEntityFrameworkStores<ApplicationDbContext>();
            builder.Services.AddDbContext<WebMedContext>(options =>
                options.UseSqlServer(builder.Configuration.GetConnectionString("WebMedContext") ?? throw new InvalidOperationException("Connection string 'WebMedContext' not found.")));
            builder.Services.AddRazorPages();
            builder.Services.AddDistributedMemoryCache(); 
            builder.Services.AddSession(); 


            var app = builder.Build();



            if (app.Environment.IsDevelopment())
            {
                app.UseMigrationsEndPoint();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                app.UseHsts();
            }

            app.UseSession();
            app.MapRazorPages();

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.MapRazorPages();

            app.Run();
        }
    }
}
