﻿using System;
using System.ComponentModel.DataAnnotations;

namespace WebMed.Models
{
	public class Medicine
	{
		public string Id { get; set; }   // Unique identifier for the medicine
		public string Name { get; set; }  // Name of the medicine
	}
}