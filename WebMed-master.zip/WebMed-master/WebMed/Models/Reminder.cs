﻿using System;
using System.ComponentModel.DataAnnotations;

namespace WebMed.Models
{
	public class Reminder
	{
		public int Id { get; set; }

		[Required]
		public string MedicinId { get; set; }

		[Required]
		public string MedicinName { get; set; }

		[Required]
		public DateTime ReminderTime { get; set; }

		public string RepeatInterval { get; set; }  // Daily, Weekly, Custom, etc.

		public int? CustomDaysInterval { get; set; }  // Only for custom intervals
	}
}