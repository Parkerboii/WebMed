﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebMed.Models
{
    public class Symptomer

    {
        public int Id { get; set; }

        [StringLength(60, MinimumLength = 3)]
        [Required]
        public string Kommentarer { get; set; } = string.Empty;

        [DataType(DataType.Date)]
        public DateTime Dato { get; set; }
        
        [Display(Name = "Systolisk Blodtryk")]
        public int Systoliske_blodtryk { get; set; }

        [Display(Name = "Diastolisk Blodtryk")]
        public int Diastoliske_blodtryk { get; set; }

        public int Puls { get; set; }

        public int Duration { get; set; }
    }
}
