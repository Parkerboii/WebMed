﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using WebMed.Models;

namespace WebMed.Data
{
    public class WebMedContext : DbContext
    {
        public WebMedContext (DbContextOptions<WebMedContext> options)
            : base(options)
        {
        }

        public DbSet<Symptomer> Symptomer { get; set; } = default!;

        public DbSet<User> Users { get; set; }
    }
}
